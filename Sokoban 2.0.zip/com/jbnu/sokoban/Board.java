package com.jbnu.sokoban;

import java.awt.Color;
import java.awt.Graphics;
import java.io.File;
import java.util.ArrayList;
import javax.swing.JPanel;

public abstract class Board extends JPanel {

	protected final int OFFSET = 30;
	protected final int SPACE = 20;

	protected int levelOfMap;

	protected ArrayList<Actor> actors;
	protected ArrayList<Baggage> baggs;
	protected ArrayList<Area> areas;
	protected Actor[][] world;

	protected Player soko;
	protected int w = 0;
	protected int h = 0;

	protected File recordFile;
	protected File mapFile;

	protected StringBuilder moves;

	protected boolean isCompleted = false;

	public int undoCnt;

	protected StringBuilder level = new StringBuilder("");
	protected Trap snake;

	public Board(int i) {

		levelOfMap = i;
		undoCnt = 5;
		mapFile = new File("resources/maps/map" + i + ".txt");
		level = FileOperator.connvertFileToString(mapFile);
		initBoard();
	}

	protected void initBoard() {
		initWorld();
	}

	public int getBoardWidth() {
		return this.w;
	}

	public int getBoardHeight() {
		return this.h;
	}

	protected void initWorld() {

		actors = new ArrayList<>();
		baggs = new ArrayList<>();
		areas = new ArrayList<>();
		int x = OFFSET;
		int y = OFFSET;

		Wall wall;
		Baggage b;
		Area a;

		for (int i = 0; i < level.length(); i++) {

			char item = level.charAt(i);

			switch (item) {

			case '\n':
				y += SPACE;
				if (this.w < x) {
					this.w = x;
				}
				x = OFFSET;
				break;

			case '#':
				wall = new Wall(x, y);
				actors.add(wall);
				x += SPACE;
				break;

			case '$':
				b = new Baggage(x, y);
				baggs.add(b);
				x += SPACE;
				break;

			case '.':
				a = new Area(x, y);
				actors.add(a);
				areas.add(a);
				x += SPACE;
				break;

			case '@':
				soko = new Player(x, y);
				x += SPACE;
				break;

			case ' ':
				actors.add(new EmptySpace(x, y));
				x += SPACE;
				break;

			case '^':
				snake = new Trap(x, y);
				actors.add(snake);
				x += SPACE;
				break;

			default:
				break;
			}

			h = y;
		}
		world = new Actor[(w - OFFSET) / SPACE + 1][(h - OFFSET) / SPACE + 1];

		for (int i = 0; i < baggs.size(); i++) {
			actors.add(baggs.get(i));
		}

		if (soko != null)
			actors.add(soko);
	}

	protected void buildWorld(Graphics g) {

		g.setColor(new Color(250, 250, 250));
		g.fillRect(0, 0, this.getWidth(), this.getHeight());
		for (int i = 0; i < actors.size(); i++) {

			Actor item = actors.get(i);

			if (item instanceof Player || item instanceof Baggage) {
				g.drawImage(item.getImage(), item.x() + 2, item.y() + 2, this);
			} else {
				g.drawImage(item.getImage(), item.x(), item.y(), this);
			}

		}
	}

	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		buildWorld(g);
	}
}
