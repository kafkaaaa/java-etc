package com.jbnu.sokoban;

import java.awt.*;
import java.awt.event.*;
import java.io.File;

public class PlayBoard extends InGameBoard {

	private final int LEFT_COLLISION = 1;
	private final int RIGHT_COLLISION = 2;
	private final int TOP_COLLISION = 3;
	private final int BOTTOM_COLLISION = 4;

	private StringBuilder baggsMoves;
	private int[] directions = new int[4];

	public PlayBoard(int i) {
		super(i);
	}

	protected void initBoard() {

		recordFile = new File("resources/saves/" + levelOfMap + "sav.txt");
		moves = new StringBuilder("");
		moves = FileOperator.connvertFileToString(recordFile);
		baggsMoves = new StringBuilder("");
		addKeyListener(new TAdapter());
		setFocusable(true);
		super.initBoard();
	}

	protected void buildWorld(Graphics g) {

		resetWorld();
		setWorld();
		super.buildWorld(g);
		g.setColor(new Color(0, 0, 0)); // �̵�Ƚ������ : ������ (0, 0, 0)
		g.drawString("moves: " + Integer.toString(move), 25, 270);

		g.drawString("Undo: Z Save: S Load: L Reset: R Change Rabbit: C ", 25, 20);

		g.drawString("Delete Replay Data: D", 25, 40);

		g.drawString("UndoRemains: " + Integer.toString(undoCnt), 25, 250);
		if (soko.getIsTrapped())
			swapDirections(directions);
		else
			setDirections(directions);
		if (bestMove == 0) {
			g.drawString("Your Least Movement: NOT CLEARED", 25, 290);
		}
		if (isCompleted) {
			if (move < bestMove || bestMove == 0) {
				FileOperator.writeFile("resources/replays/level" + levelOfMap + "replay.txt", soko.getMoves());
			}
			g.drawString("Completed", 25, 60);
		}

	}

	private void resetWorld() {

		for (int i = 0; i < (w - OFFSET) / SPACE; i++) {
			for (int j = 0; j < (h - OFFSET) / SPACE; j++) {
				Actor item = new EmptySpace(0, 0);
				world[i][j] = item;
			}
		}
	}

	private void setWorld() {

		for (int i = 0; i < actors.size(); i++) {
			Actor item = actors.get(i);
			world[(item.x() - OFFSET) / SPACE][(item.y() - OFFSET) / SPACE] = item;
		}
	}

	private class TAdapter extends KeyAdapter {
		@Override
		public void keyPressed(KeyEvent e) {
			if (isCompleted) { // ���� Ŭ�����(Completed) Ű���� �Է� ���� ����
				return;
			}

			int key = e.getKeyCode();

			switch (key) {

			case KeyEvent.VK_LEFT:
				moveMovables(directions[0]);
				break;

			case KeyEvent.VK_RIGHT:
				moveMovables(directions[1]);
				break;

			case KeyEvent.VK_UP:
				moveMovables(directions[2]);
				break;

			case KeyEvent.VK_DOWN:
				moveMovables(directions[3]);
				break;

			case KeyEvent.VK_Z: // undo
				undoMoves();
				break;

			case KeyEvent.VK_S:
				saveBoardState();
				break;

			case KeyEvent.VK_L:
				loadBoardState();
				break;

			case KeyEvent.VK_R: // �ٽ��ϱ�
				restartLevel();
				break;
			case KeyEvent.VK_J:
				if (canSokoJump())
					soko.jump(SPACE);
				break;
			case KeyEvent.VK_C:
				soko.changePlayerColor();
				break;

			case KeyEvent.VK_D: // ���÷��� ����
				deleteReplay();
				break;

			default:
				return;
			}
			repaint();
			isCompleted();
		}
	}

	private boolean canSokoJump() {

		if (move == 0)
			return false;

		int direction = soko.getMoves().charAt(move - 1) - '0';
		Actor item = getActorNearBy(soko, direction);
		Actor temp = getActorNearBy(item, direction);

		if (item instanceof Baggage) {
			if (temp instanceof Wall || temp instanceof Baggage)
				return false;
		}
		move++;
		return true;
	}

	private void moveMovables(int direction) {

		Actor item = getActorNearBy(soko, direction);
		if (item instanceof Wall) {
			return;
		}

		if (item instanceof Baggage) {
			if (checkBaggCanMove((Baggage) item, direction)) {
				((Baggage) item).moveDirec(direction, SPACE);
				baggsMoves.append(direction);
			} else
				return;
		} else {
			baggsMoves.append('N');
		}

		soko.moveDirec(direction, SPACE);
		checkPlayerTrapped();
		move++;
	}

	private boolean checkBaggCanMove(Baggage bagg, int collision) {

		Actor temp = getActorNearBy(bagg, collision);

		if (temp instanceof EmptySpace || temp instanceof Area) {
			if (temp instanceof Area)
				bagg.setIsInArea(true);
			else
				bagg.setIsInArea(false);
			return true;
		} else
			return false;
	}

	private Actor getActorNearBy(Actor actor, int type) {

		Actor actorToCheck;
		int x = (actor.x() - OFFSET) / SPACE;
		int y = (actor.y() - OFFSET) / SPACE;

		switch (type) {

		case LEFT_COLLISION:
			actorToCheck = world[x - 1][y];
			return actorToCheck;
		case RIGHT_COLLISION:
			actorToCheck = world[x + 1][y];
			return actorToCheck;
		case TOP_COLLISION:
			actorToCheck = world[x][y - 1];
			return actorToCheck;
		case BOTTOM_COLLISION:
			actorToCheck = world[x][y + 1];
			return actorToCheck;
		default:
			break;
		}

		return new EmptySpace(0, 0);
	}

	public void deleteReplay() {

		bestMove = 0;
		FileOperator.writeFile("resources/replays/level" + levelOfMap + "replay.txt", "");
	}

	public boolean isCompleted() {

		int numOfFinished = 0;

		for (int i = 0; i < areas.size(); i++) {
			Actor area = areas.get(i);
			for (int j = 0; j < baggs.size(); j++) {
				Actor bagg = baggs.get(j);
				if (bagg.x() == area.x() && bagg.y() == area.y()) {
					numOfFinished++;
				}
			}
		}

		if (numOfFinished == baggs.size()) {
			soko.setWinImage();
			isCompleted = true;
			return true;
		}
		return false;
	}

	private void restartLevel() {
		restartActors();
		resetUndoCount();
	}

	private void restartActors() {
		actors.clear();
		baggs.clear();
		move = 0;
		initWorld();
	}

	private void resetUndoCount() {
		undoCnt = 5;
	}

	private void undoMoves() {

		if (undoCnt == 0 || move == 0)
			return;

		moves = soko.getMoves();
		restartActors();

		while (move < moves.length() - 1) {
			replayMovables(moves);
			repaint();
		}
		undoCnt--;
	}

	private void saveBoardState() {
		FileOperator.writeFile("resources/saves/" + levelOfMap + "sav.txt", soko.getMoves());
	}

	private void loadBoardState() {

		moves = FileOperator.connvertFileToString(recordFile);
		restartLevel();

		while (move < moves.length()) {
			replayMovables(moves);
			repaint();
		}
	}

	private void setDirections(int directions[]) {
		directions[0] = LEFT_COLLISION;
		directions[1] = RIGHT_COLLISION;
		directions[2] = TOP_COLLISION;
		directions[3] = BOTTOM_COLLISION;
	}

	private void swapDirections(int directions[]) {
		directions[0] = RIGHT_COLLISION;
		directions[1] = LEFT_COLLISION;
		directions[2] = BOTTOM_COLLISION;
		directions[3] = TOP_COLLISION;
	}

	public String getBestMove() {

		if (bestMove == 0)
			return "N/D";
		else
			return Integer.toString(bestMove);
	}
}