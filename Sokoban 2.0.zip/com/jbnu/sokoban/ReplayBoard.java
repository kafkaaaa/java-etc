package com.jbnu.sokoban;

import java.awt.*;
import java.io.File;

public class ReplayBoard extends InGameBoard {

	private boolean isRunning;

	public ReplayBoard(int i) {
		super(i);
	}

	protected void initBoard() {

		isRunning = true;
		AnimThread am = new AnimThread();
		setFocusable(true);
		super.initBoard();
		recordFile = new File("resources/replays/level" + levelOfMap + "replay.txt");
		moves = new StringBuilder("");
		moves = FileOperator.connvertFileToString(recordFile);
		if (soko != null)
			am.start();
	}

	protected void buildWorld(Graphics g) {

		if (moves.equals(new StringBuilder(""))) {
			g.setColor(new Color(252, 0, 0));
			g.drawString("No File", 25, 20);
		}
		super.buildWorld(g);

	}

	@Override
	public void paintComponent(Graphics g) {

		super.paintComponent(g);
		buildWorld(g);
	}

	private class AnimThread extends Thread {
		@Override
		public void run() {
			while (move < moves.length() && isRunning) {
				try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				replayMovables(moves);
				repaint();
			}
			soko.setWinImage();
			repaint();
		}
	}

	public void setIsRunning(boolean b) {
		isRunning = b;
	}

}
