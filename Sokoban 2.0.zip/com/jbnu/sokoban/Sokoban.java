package com.jbnu.sokoban;

import java.awt.EventQueue;

public class Sokoban {

	public Sokoban() {

		new IntroUI();

		// BGM ���
		BgmPlayer bgm = BgmPlayer.getInstance();
		bgm.play("resources/sounds/gameBGM.wav", true);
	}
	
	public static void main(String[] args) {

		EventQueue.invokeLater(() -> {

			new Sokoban();
		});
	}

}
