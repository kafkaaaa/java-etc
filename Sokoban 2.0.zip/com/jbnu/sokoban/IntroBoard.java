package com.jbnu.sokoban;

public class IntroBoard extends Board {

	public IntroBoard(int i) {
		super(i);
	}
	
}
