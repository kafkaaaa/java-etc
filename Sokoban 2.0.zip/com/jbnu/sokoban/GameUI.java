package com.jbnu.sokoban;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class GameUI extends JFrame {

	public GameUI(int WIDTH, int HEIGHT) {

		JPanel mainui = new MainUI();
		add(mainui);

		setVisible(true);
		setTitle("Sokoban - Playing");
		setSize(WIDTH, HEIGHT);
		setResizable(false);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}
}
