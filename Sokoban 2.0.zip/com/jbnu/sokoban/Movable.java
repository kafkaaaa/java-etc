package com.jbnu.sokoban;

public class Movable extends Actor {

	public Movable(int x, int y) {
		super(x, y);
	}

	public void move(int x, int y) {

		int dx = x() + x;
		int dy = y() + y;

		setX(dx);
		setY(dy);
	}

	public void moveDirec(int direction, int space) {

		switch (direction) {

		case 1:
			move(-space, 0);
			break;
		case 2:
			move(space, 0);
			break;
		case 3:
			move(0, -space);
			break;
		case 4:
			move(0, space);
			break;
		}
	}

}
