package com.jbnu.sokoban;

public class EmptySpace extends Actor {

	public EmptySpace(int x, int y) {
		super(x, y);
	}
	
}
