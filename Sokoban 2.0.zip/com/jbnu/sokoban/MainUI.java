package com.jbnu.sokoban;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class MainUI extends JPanel {

	private Container buttons = new Container();
	private Board board;
	private boolean isReplaying;
	private static final int nOfBtn = 6;
	private static final int PLAY = 2020;
	private static final int REPLAY = 2016;

	public MainUI() {

		requestFocus();
		initMainUI(new IntroBoard(2020));
	}

	public void initMainUI(Board board) {

		buttons.removeAll();
		makePlayBtn();
		setLayout(new BorderLayout());
		add(board, BorderLayout.CENTER);
		add(buttons, BorderLayout.SOUTH);
		board.setFocusable(true);
		updateUI();
	}

	public void showBoard(int level) {

		removeAll();
		buttons.removeAll();

		checkIsReplaying();

		if (isReplaying) {
			removeAll();
			board = new ReplayBoard(level);
		} else {
			removeAll();
			board = new PlayBoard(level);
		}

		initMainUI(board);
		board.requestFocus();
	}

	public void makePlayBtn() {

		JButton[] btn = new JButton[nOfBtn + 1];
		buttons.setLayout(new GridLayout(2, 3));

		for (int i = 1; i < nOfBtn; i++) {

			int level = i;

			String bestScore = new PlayBoard(level).getBestMove();
			String btnText = "Level " + level + ": " + bestScore;

			buttons.add(btn[i] = new JButton(btnText));
			setGameButtonStyle(btn[i]);

			btn[i].addMouseListener(new MouseAdapter() {
				@Override
				public void mousePressed(MouseEvent e) {
					showBoard(level);
				}
			});
		}

		buttons.add(btn[nOfBtn] = new JButton("REPLAY"));
		if (isReplaying)
			btn[nOfBtn].setText("PLAY");
		setBoardButtonStyle(btn[nOfBtn]);

		btn[nOfBtn].addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				removeAll();
				checkIsReplaying();
				if (isReplaying) {
					initMainUI(new IntroBoard(PLAY));
					isReplaying = false;
				} else {
					initMainUI(new IntroBoard(REPLAY));
					isReplaying = true;
				}
				repaint();
			}
		});
	}

	private void setGameButtonStyle(JButton gameBtn) {
		gameBtn.setBackground(Color.WHITE);
		gameBtn.setForeground(Color.BLACK);
		gameBtn.setFont(new Font("����", Font.ITALIC, 14));
	}

	private void setBoardButtonStyle(JButton boardBtn) {
		boardBtn.setBackground(Color.BLACK);
		boardBtn.setForeground(Color.WHITE);
		boardBtn.setFont(new Font("����", Font.BOLD, 13));
	}

	private void checkIsReplaying() {
		if (board instanceof ReplayBoard)
			((ReplayBoard) board).setIsRunning(false);
	}

}
