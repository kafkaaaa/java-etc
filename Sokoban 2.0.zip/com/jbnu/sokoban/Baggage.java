package com.jbnu.sokoban;

import java.awt.Image;
import javax.swing.ImageIcon;

public class Baggage extends Movable {

	private boolean isInArea;

	public Baggage(int x, int y) {

		super(x, y);
		isInArea = false;
		initBaggage();
	}

	public void setIsInArea(boolean bool) {
		isInArea = bool;
	}

	public boolean getIsInArea() {
		return isInArea;
	}

	private void initBaggage() {
		ImageIcon iicon = new ImageIcon("resources/images/baggage.png");
		Image image = iicon.getImage();
		setImage(image);
	}

}
