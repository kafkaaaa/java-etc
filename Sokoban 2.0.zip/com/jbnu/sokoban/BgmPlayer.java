package com.jbnu.sokoban;

import java.io.File;
import javax.sound.sampled.*;

public class BgmPlayer {

	/* Refactoring : Singleton pattern */
	private static BgmPlayer instance = new BgmPlayer();

	private BgmPlayer() {}

	public static BgmPlayer getInstance() {
		if ( instance == null ) {
            throw new IllegalStateException();
        }
		return instance;
	}

	public void play(String fileName, boolean isLoop) {

		try {
			AudioInputStream ais = AudioSystem.getAudioInputStream(new File(fileName));
			Clip clip = AudioSystem.getClip();
			clip.stop();
			clip.open(ais);
			clip.start();
			if (isLoop)
				clip.loop(Clip.LOOP_CONTINUOUSLY);
			
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
