package com.jbnu.sokoban;

import java.awt.Graphics;
import java.io.File;

public class InGameBoard extends Board {

	protected int bestMove;
	protected int move;

	public InGameBoard(int i) {
		super(i);
		bestMove = FileOperator.connvertFileToString(new File("resources/replays/level" + i + "replay.txt")).length();
		move = 0;
	}

	protected void buildWorld(Graphics g) {
		super.buildWorld(g);
		if (move != 0)
			g.drawString("moves: " + Integer.toString(move), 25, 270);
	}

	protected void replayMovables(StringBuilder moves) {
		replayPlayer(moves);
		replayBaggages(moves);
		checkPlayerTrapped();
		move++;
	}

	protected void checkPlayerTrapped() {

		if (snake == null)
			return;

		if (soko.x() == snake.x() && soko.y() == snake.y()) {
			soko.setIsTrapped(true);
			actors.remove(snake);
		}
	}

	private void replayBaggages(StringBuilder moves) {

		Baggage baggToMove = new Baggage(0, 0);

		for (int i = 0; i < baggs.size(); i++) {
			if (soko.x() == baggs.get(i).x() && soko.y() == baggs.get(i).y())
				baggToMove = baggs.get(i);
		}

		switch (moves.charAt(move)) {

		case '1':
			baggToMove.move(-SPACE, 0);
			break;

		case '2':
			baggToMove.move(SPACE, 0);
			break;

		case '3':
			baggToMove.move(0, -SPACE);
			break;

		case '4':
			baggToMove.move(0, SPACE);
			break;

		default:
			break;
		}
	}

	private void replayPlayer(StringBuilder moves) {

		switch (moves.charAt(move)) {

		case '1':
			soko.move(-SPACE, 0);
			break;

		case '2':
			soko.move(SPACE, 0);
			break;

		case '3':
			soko.move(0, -SPACE);
			break;

		case '4':
			soko.move(0, SPACE);
			break;

		case '5':
			soko.jump(SPACE);
			break;

		default:
			return;
		}
	}

}
