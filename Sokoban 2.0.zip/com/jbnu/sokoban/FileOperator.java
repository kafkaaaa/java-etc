package com.jbnu.sokoban;

import java.io.*;

public class FileOperator {

	public static StringBuilder connvertFileToString(File file) {

		StringBuilder maker = new StringBuilder("");

		try {
			FileReader filereader = new FileReader(file);
			int singleCh = 0;

			while ((singleCh = filereader.read()) != -1) {
				maker.append((char) singleCh);
			}
			filereader.close();

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return maker;
	}

	public static void writeFile(String fileName, StringBuilder content) {

		try {
			File file = new File(fileName);
			FileWriter fw = new FileWriter(file);
			fw.write(content.toString());
			fw.close();

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void writeFile(String fileName, String content) {

		try {
			File file = new File(fileName);
			FileWriter fw = new FileWriter(file);
			fw.write(content);
			fw.close();

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
