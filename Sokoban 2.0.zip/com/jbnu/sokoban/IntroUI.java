package com.jbnu.sokoban;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class IntroUI extends JFrame {

	private Image screenImage;
	private Graphics screenGraphic;

	private ImageIcon startButton = new ImageIcon("resources/images/startButton.png");
	private ImageIcon exitButton = new ImageIcon("resources/images/exitButton.png");

	private JButton startBtn = new JButton(startButton);
	private JButton exitBtn = new JButton(exitButton);
	private ImageIcon backGround = new ImageIcon("resources/images/background.png");

	private static final int WIDTH = 350;
	private static final int HEIGHT = 400;

	public IntroUI() {

		setUndecorated(true);
		setSize(WIDTH, HEIGHT);
		setResizable(false);
		setLocationRelativeTo(null);
		setVisible(true);
		setBackground(new Color(0, 0, 0, 0));
		setLayout(null);

		// start ��ư
		startBtn.setBounds(75, 140, 190, 60);
		startBtn.setBorderPainted(false);
		startBtn.setContentAreaFilled(false);
		startBtn.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				startBtn.setVisible(false);
				exitBtn.setVisible(false);
				dispose();
				new GameUI(WIDTH, HEIGHT);
			}
		});
		add(startBtn);

		// exit ��ư
		exitBtn.setBounds(75, 230, 190, 60);
		exitBtn.setBorderPainted(false);
		exitBtn.setContentAreaFilled(false);
		exitBtn.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				// exit ��ư
				try {
					Thread.sleep(1000);
				} catch (InterruptedException ex) {
					ex.printStackTrace();
				}
				System.exit(0);
			}
		});
		add(exitBtn);

	}

	public void paint(Graphics g) {
		screenImage = createImage(WIDTH, HEIGHT);
		screenGraphic = screenImage.getGraphics();
		screenDraw(screenGraphic);
		g.drawImage(screenImage, 0, 0, null);
	}

	public void screenDraw(Graphics g) {
		g.drawImage(backGround.getImage(), 0, 0, null);
		paintComponents(g);
		this.repaint();
	}

}
