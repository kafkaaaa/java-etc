package com.jbnu.sokoban;

import java.io.File;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;

public class EffectSoundPlayer {

	private final static String JUMPSOUNDFILE = "resources/sounds/jumpSound.wav";
	private final static String MOVESOUNDFILE = "resources/sounds/footStepSound.wav";

	public static void playJumpSound() {
		play(JUMPSOUNDFILE);
	}

	public static void playMoveSound() {
		play(MOVESOUNDFILE);
	}

	private static void play(String fileName) {
		try {
			AudioInputStream ais = AudioSystem.getAudioInputStream(new File(fileName));
			Clip clip = AudioSystem.getClip();
			clip.stop();
			clip.open(ais);
			clip.start();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
