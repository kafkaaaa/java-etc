package com.jbnu.sokoban;

import java.awt.Image;
import javax.swing.ImageIcon;

public class Player extends Movable {

	private ImageIcon normalImage;
	private ImageIcon leftImage;
	private ImageIcon rightImage;
	private ImageIcon winImage;
	private static int color = 0;
	private StringBuilder moves;
	private ImageIcon playerImages[][] = new ImageIcon[4][3];
	private boolean isTrapped;

	public Player(int x, int y) {
		super(x, y);
		initPlayer();
		isTrapped = false;
		moves = new StringBuilder("");
	}

	private void recordMove(char direction) {
		moves.append(direction);
	}

	public StringBuilder getMoves() {
		return moves;
	}

	private void initPlayer() {

		for (int i = 0; i < 3; i++) {
			playerImages[0][i] = new ImageIcon("resources/images/player" + i + ".png");
		}

		for (int i = 0; i < 3; i++) {
			playerImages[1][i] = new ImageIcon("resources/images/playerleft" + i + ".png");
		}

		for (int i = 0; i < 3; i++) {
			playerImages[2][i] = new ImageIcon("resources/images/playerright" + i + ".png");
		}

		for (int i = 0; i < 3; i++) {
			playerImages[3][i] = new ImageIcon("resources/images/playerwin" + i + ".png");
		}

		setColor(color);
		Image image = normalImage.getImage();
		setImage(image);
	}

	public void move(int x, int y) {

		super.move(x, y);
		
		// �����϶� ���� ���ڱ� �Ҹ� ���
		if (x + y > SPACE || x + y < -SPACE)
			EffectSoundPlayer.playJumpSound();
		else
			EffectSoundPlayer.playMoveSound();

		// Player�� �¿� ���(�̹���) �ٸ��� ����
		if (y > 0) {
			setImage(normalImage.getImage());
			recordMove('4');
		}
		if (y < 0) {
			setImage(normalImage.getImage());
			recordMove('3');
		}
		if (x < 0) {
			setImage(leftImage.getImage());
			recordMove('1');
		}
		if (x > 0) {
			setImage(rightImage.getImage());
			recordMove('2');
		}
	}

	public void changePlayerColor() {

		if (color == 2) {
			color = -1;
		}
		color++;
		setColor(color);
	}

	// ���� Clear�� ĳ���� �̹��� ���� (���۶� on)
	private void setColor(int i) {

		color = i;
		normalImage = playerImages[0][i];
		leftImage = playerImages[1][i];
		rightImage = playerImages[2][i];
		winImage = playerImages[3][i];
		setImage(normalImage.getImage());
	}

	public int getColor() {
		return color;
	}

	public void jump(int space) {

		char lastDirection = moves.charAt(moves.length() - 1);

		switch (lastDirection) {

		case '1':
			move(-space * 2, 0);

			break;
		case '2':
			move(space * 2, 0);

			break;
		case '3':
			move(0, -space * 2);

			break;
		case '4':
			move(0, space * 2);

			break;
		}

		moves.setCharAt(moves.length() - 1, '5');
	}

	public void setWinImage() {
		setImage(winImage.getImage());
	}

	public boolean getIsTrapped() {
		return isTrapped;
	}

	public void setIsTrapped(boolean b) {
		isTrapped = b;
	}

}
