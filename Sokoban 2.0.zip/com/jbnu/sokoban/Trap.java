package com.jbnu.sokoban;

import java.awt.Image;
import javax.swing.ImageIcon;

public class Trap extends Actor {

	public Trap(int x, int y) {
		super(x, y);
		initTrap();
	}

	private void initTrap() {
		ImageIcon iicon = new ImageIcon("resources/images/trap.png");
		Image image = iicon.getImage();
		setImage(image);
	}

}
